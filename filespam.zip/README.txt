Its my first program on github :D

Fractions must be written in the format with dot. Example: 0.5